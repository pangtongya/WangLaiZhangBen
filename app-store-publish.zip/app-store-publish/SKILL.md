---
name: app-store-publish
description: This skill should be used when the user wants to publish an iOS app to the App Store, needs to understand the App Store submission process, requires a pre-submission checklist, or needs to fill out App Store Connect information. Triggers include phrases like "上架 App Store", "发布到 App Store", "App Store 上架流程", "准备提交审核", or when the user is ready to distribute their app.
agent_created: true
---

# App Store Publish Skill

## Overview

This skill provides a complete workflow for publishing iOS apps to the App Store. It includes a pre-submission checklist, detailed explanations of App Store Connect fields, best practices, and common pitfalls to avoid. Use this skill when preparing to submit an app for the first time or when updating an existing app.

## When to Use This Skill

- User says "上架 App Store", "发布到 App Store", "App Store 上架流程"
- User is ready to distribute their iOS app
- User needs to prepare App Store Connect information
- User wants to understand the submission process
- User has been rejected and needs to fix issues

## Complete Workflow

### Phase 1: Pre-Submission Preparation

1. **Run the Pre-Submission Checklist**
   - Load `references/checklist.md` to review all items
   - Verify app functionality, code signing, icons, permissions
   - Ensure privacy policy URL is accessible (https://)
   - Prepare screenshots and preview videos

2. **Prepare App Store Connect Information**
   - Load `references/app-store-connect-fields.md` for detailed field explanations
   - Prepare app name, subtitle, description, keywords
   - Write privacy policy and support URL content
   - Determine category and age rating

3. **Build and Archive the App**
   - Use Xcode: Product → Archive
   - Validate the archive before distribution
   - Fix any validation errors
   - Upload to App Store Connect

### Phase 2: App Store Connect Configuration

1. **Create/Update App Record**
   - Log in to App Store Connect (https://appstoreconnect.apple.com)
   - Create new app or select existing app
   - Fill in all required information (see `references/app-store-connect-fields.md`)

2. **Upload Screenshots and Preview**
   - Upload screenshots for different device sizes
   - Upload preview video (optional)
   - Ensure images meet size and format requirements

3. **Configure App Privacy**
   - Answer questions about data collection
   - Declare all data types used
   - Ensure privacy policy matches declarations

4. **Set Age Rating**
   - Answer content questions
   - System will assign appropriate age rating

### Phase 3: Submission and Review

1. **Submit for Review**
   - Click "Submit for Review" in App Store Connect
   - Answer export compliance, content rights, advertising identifier questions
   - Confirm all information is correct

2. **Wait for Review**
   - Review typically takes 24-48 hours
   - Monitor App Store Connect for status updates
   - Prepare to respond to feedback if rejected

3. **Handle Rejection (if applicable)**
   - Load `references/best-practices.md` for common rejection reasons
   - Read rejection feedback carefully
   - Fix issues and resubmit
   - Reply to Apple in App Store Connect

### Phase 4: Post-Release

1. **Monitor Performance**
   - Check App Store Connect Analytics
   - Monitor crashes and user feedback
   - Track downloads and revenue

2. **Respond to Reviews**
   - Reply to user reviews professionally
   - Address complaints and bugs

3. **Plan Updates**
   - Regular updates improve rankings
   - Fix bugs and add features
   - Update screenshots and description if needed

## Key Tools

### Xcode
- **Archive**: Product → Archive
- **Validate**: Window → Organizer → Distribute App → Validate App
- **Upload**: Window → Organizer → Distribute App → App Store Connect

### App Store Connect
- **Website**: https://appstoreconnect.apple.com
- **Purpose**: Manage app information, submit for review, monitor performance

### Transporter (optional)
- **Purpose**: Upload large binaries or when Xcode upload fails
- **Download**: Mac App Store

## References

This skill includes three reference documents:

1. **`references/checklist.md`** - Complete pre-submission checklist
   - Use this first to ensure app is ready
   - Covers code signing, icons, permissions, testing, legal requirements
   - Includes screenshot and preview video specifications

2. **`references/app-store-connect-fields.md`** - Detailed field explanations
   - Use when filling out App Store Connect information
   - Explains every field with limits, requirements, and suggestions
   - Includes examples for app name, description, keywords

3. **`references/best-practices.md`** - Best practices and common pitfalls
   - Use when preparing for submission or handling rejection
   - Covers best practices for screenshots, descriptions, testing
   - Lists common rejection reasons and solutions
   - Includes post-rejection workflow

## Quick Start Guide

For a new app submission:

1. **Run checklist**: Read `references/checklist.md` and verify all items
2. **Prepare metadata**: Use `references/app-store-connect-fields.md` to prepare app name, description, keywords
3. **Build and upload**: Use Xcode to archive and upload the app
4. **Fill App Store Connect**: Use prepared metadata to fill all required fields
5. **Submit**: Click "Submit for Review" and answer final questions
6. **Wait**: Review typically takes 24-48 hours
7. **If rejected**: Read `references/best-practices.md` for common issues and solutions

## Important Notes

### Privacy Policy URL
- **Must be https://**
- **Must be accessible without the app**
- **Recommended hosting**: GitHub Pages, cloud storage static website
- **Example**: https://username.github.io/repo/privacy

### Code Signing
- **Development**: For testing on devices
- **Distribution**: For App Store submission
- **Ad Hoc**: For testing on specific devices before release
- **Enterprise**: For internal distribution (large companies)

### Version Numbers
- **Version (CFBundleShortVersionString)**: User-visible (e.g., 1.0.0)
- **Build (CFBundleVersion)**: Must increment each upload (e.g., 1, 2, 3)
- **Format**: Use semantic versioning (major.minor.patch)

### Screenshots
- **Minimum**: 3 screenshots
- **Maximum**: 10 screenshots
- **Sizes**: Vary by device (see checklist for details)
- **Tips**: Show core features, visually appealing, no fake content

## Common Mistakes to Avoid

1. **Privacy policy URL not accessible**
   - Solution: Use reliable hosting, test URL before submission

2. **Screenshots don't match app**
   - Solution: Use real screenshots from the app

3. **Missing permission descriptions in Info.plist**
   - Solution: Add all required usage descriptions

4. **App crashes during review**
   - Solution: Test thoroughly on real devices, handle edge cases

5. **Keyword stuffing**
   - Solution: Use relevant keywords only, no competitor names

## Example Workflow for "来记个账" App

1. **Check privacy policy URL**: Ensure https://pangtongya.github.io/WangLaiZhangBen/privacy is accessible
2. **Prepare screenshots**: Take screenshots of main features (记账、对比、我的)
3. **Fill App Store Connect**:
   - Name: 来记个账
   - Subtitle: 记录前任现任钱财往来
   - Category: 财务
   - Keywords: 记账,账本,前任,钱财,AA制
   - Description: [Prepare using structure in fields guide]
4. **Archive and upload**: Use Xcode
5. **Submit for review**: Answer questions (Export Compliance: No, Content Rights: No, Advertising Identifier: No)
6. **Wait for review**: 24-48 hours
7. **If rejected**: Check `references/best-practices.md` and fix issues

## Loading References

When using this skill, load the reference documents as needed:

- **Start with checklist**: Always run the pre-submission checklist first
- **Load fields guide**: When preparing App Store Connect information
- **Load best practices**: When handling rejection or optimizing after release

References are stored in the `references/` directory and should be read into context as needed. Do not load all references at once - load them progressively based on the current phase of the workflow.
