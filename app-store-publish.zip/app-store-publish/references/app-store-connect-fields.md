# App Store Connect 字段详解

## 📱 App 信息 (App Information)

### App 名称 (App Name)
- **限制**：30 字符以内
- **说明**：显示在 App Store 和应用图标下方的名称
- **建议**：简洁、易记、体现核心功能
- **示例**：来记个账、微信、抖音

### 副标题 (Subtitle)
- **限制**：30 字符以内
- **说明**：显示在 App 名称下方的简短描述
- **建议**：突出核心价值或主要特色
- **示例**：记录前任现任钱财往来

### 主要类别 (Primary Category)
- **必填**：是
- **选项**：商务、天气、社交、参考、导航、新闻、册子、财务、摄影与录像、生活、效率、教育、旅游、游戏、儿童、娱乐、美食与饮品、健康与健身、音乐、图书、医疗、杂志与报纸、体育、实用工具、购物、贴纸、天气
- **建议**：选择最符合 App 功能的类别

### 次要类别 (Secondary Category)
- **必填**：否
- **说明**：可选，进一步细分 App 类型
- **建议**：如果主要类别不够精确，选择合适次要类别

### 关键词 (Keywords)
- **限制**：100 字符以内
- **说明**：用于 App Store 搜索，用逗号分隔
- **建议**：
  - 使用用户可能搜索的词汇
  - 不包含 App 名称
  - 不包含无关词汇
  - 使用单数/复数（系统自动处理）
- **示例**：记账,账本,前任,钱财,AA制

### 描述 (Description)
- **限制**：4000 字符以内
- **说明**：详细描述 App 功能和特色
- **建议**：
  - 前几行最重要（预览时显示）
  - 使用列表格式突出功能
  - 包含用户收益（不只是功能列表）
  - 更新日志单独放在"最近更新"部分
- **结构建议**：
  ```
  [吸引人的开头 - 1-2 句话]
  
  [核心功能列表]
  - 功能 1：说明
  - 功能 2：说明
  
  [目标用户]
  
  [联系方式/支持]
  ```

### 推广文本 (Promotional Text)
- **限制**：170 字符以内
- **说明**：显示在描述上方的促销信息
- **特点**：**不需要更新版本就可以修改**
- **建议**：用于限时促销、新功能预告等

### 技术支持 URL (Support URL)
- **必填**：是
- **说明**：用户获取技术支持的网页
- **建议**：创建简单网页，包含常见问题、联系方式

### 营销 URL (Marketing URL)
- **必填**：否
- **说明**：推广 App 的网页
- **建议**：如果有产品官网，填写此处

### 隐私政策 URL (Privacy Policy URL)
- **必填**：是（除非只在本国发布且不涉及用户数据）
- **说明**：完整隐私政策的网页
- **要求**：
  - 必须是 https://
  - 内容完整
  - 可在无 App 情况下访问
- **建议**：使用 GitHub Pages、腾讯云等托管

## 📸 截图和预览 (Screenshots and Previews)

### iPhone 截图
- **要求**：至少 3 张，最多 10 张
- **尺寸**：
  - 6.7" (iPhone 17 Pro Max): 1290 x 2796 px
  - 6.5" (iPhone 17 Pro): 1242 x 2688 px
  - 5.5" (iPhone 8 Plus): 1242 x 2208 px（可选）
- **建议**：
  - 展示核心功能
  - 有视觉吸引力
  - 不包含虚假内容
  - 不包含状态栏（可选）

### iPad 截图（如适用）
- **尺寸**：
  - 12.9" iPad Pro: 2048 x 2732 px
  - 其他尺寸可选

### App 预览视频（可选）
- **时长**：15-30 秒
- **大小**：< 500 MB
- **格式**：.mov, .mp4, .m4v
- **建议**：
  - 展示核心功能使用
  - 前 5 秒吸引人
  - 不包含音频也可（可选）

## 🔞 年龄分级 (Age Rating)

### 问题列表
需要回答以下问题来确定年龄分级：

1. **Cartoon or Fantasy Violence**（卡通或幻想暴力）
2. **Realistic Violence**（真实暴力）
3. **Sexual Content or Nudity**（性内容或裸体）
4. **Profanity or Crude Humor**（亵渎或粗俗幽默）
5. **Alcohol, Tobacco, or Drug Use or References**（酒精、烟草或药物使用或提及）
6. **Mature/Suggestive Themes**（成人/暗示性主题）
7. **Simulated Gambling**（模拟赌博）
8. **Horror/Fear Themes**（恐怖/惊悚主题）
9. **Prolonged Graphic or Sadistic Realistic Violence**（长时间的图形或虐待真实暴力）
10. **Graphic Sexual Content and Nudity**（图形性内容和裸体）
11. **Unrestricted Web Access**（无限制网络访问）
12. **Gambling and Contests**（赌博和竞赛）

### 分级结果
- **4+**：适合所有年龄
- **9+**：适合 9 岁以上
- **12+**：适合 12 岁以上
- **17+**：仅适合 17 岁以上
- **18+**：仅适合 18 岁以上（某些地区）

## 🔒 App 隐私 (App Privacy)

### 需要声明的数据类型

#### 联系信息 (Contact Info)
- 姓名
- 电子邮件
- 电话号码
- 住址

#### 健康与健身 (Health and Fitness)
- 健康数据
- 健身数据

#### 财务信息 (Financial Info)
- 付款信息
- 信用历史
- 其他财务信息

#### 位置 (Location)
- 精确位置
- 粗略位置

#### 敏感信息 (Sensitive Info)
- 种族或族裔起源
- 性取向
- 怀孕或生育信息
- 残疾情况
- 会员资格

#### 联系人 (Contacts)
- 联系人列表

#### 用户内容 (User Content)
- 电子邮件
- 短信
- 照片或视频
- 音频数据
- 游戏内容
- 客户支持

#### 浏览历史 (Browsing History)
- 网页浏览
- 搜索历史

#### 搜索和助手 (Search and Assistant)
- 语音或文本搜索
- 助手对话记录

#### 标识符 (Identifiers)
- 用户 ID
- 设备 ID

#### 购买历史 (Purchase History)
- 购买历史

#### 使用数据 (Usage Data)
- 产品交互
- 广告数据

#### 诊断 (Diagnostics)
- 崩溃数据
- 性能数据
- 其他诊断数据

### 每个数据类型需要回答
1. **是否用于追踪目的**？(Used for Tracking)
2. **是否与用户身份关联**？(Linked to User)
3. **是否用于 App 功能**？(Used for App Functionality)
4. **是否用于第三方广告**？(Used for Third-Party Advertising)
5. **是否用于开发者的广告**？(Used for Developer's Advertising)
6. **是否用于 analytics**？(Used for Analytics)
7. **是否用于产品个性化**？(Used for Product Personalization)
8. **是否用于其他目的**？(Used for Other Purposes)

### 隐私政策要求
如果收集任何用户数据，必须：
- 在隐私政策中详细说明
- 获得用户同意（如适用）
- 提供数据访问和删除机制

## 📄 版权信息 (Copyright)

- **格式**：© 年份 公司名称
- **示例**：© 2026 庞通

## 🌐 本地化（如适用）

每种语言需要单独填写：
- App 名称
- 副标题
- 描述
- 关键词
- 截图（可选）

## ❓ 审核问答 (Review Questions)

提交审核时需要回答：

### 1. 出口合规 (Export Compliance)
- **问题**：App 是否包含加密？
- **通常答案**：否（除非 App 使用加密功能）

### 2. 内容版权 (Content Rights)
- **问题**：App 是否包含、显示或访问第三方内容？
- **通常答案**：是/否（根据实际情况）

### 3. 广告标识符 (Advertising Identifier)
- **问题**：App 是否使用 IDFA？
- **通常答案**：否（除非使用广告追踪）

## 🎯 分发选项 (Distribution Options)

### 价格与销售范围 (Price and Availability)
- **价格**：选择免费或付费
- **销售范围**：选择上架国家/地区
- **教育优惠**：是否参与教育优惠

### 分阶段发布 (Phased Release)
- **说明**：逐步向用户推送更新
- **建议**：大型更新建议开启

## 📊  Game Center（如适用）
- 是否启用 Game Center
- 排行榜设置
- 成就设置

## 💰 应用内购买（如适用）
- 产品 ID
- 产品名称
- 价格
- 描述
- 截图

## 📝 版本更新说明 (What's New in This Version)
- **限制**：无明确限制，但建议简洁
- **说明**：描述此版本的新功能或修复
- **建议**：
  - 突出重要更新
  - 使用列表格式
  - 包含 bug 修复说明
