# App Store 上架前检查清单 (Pre-submission Checklist)

## 📋 必检项目

### 1. App 基本信息
- [ ] Bundle ID 正确（例如：com.pangtong.WangLaiZhangBen）
- [ ] 版本号 (CFBundleShortVersionString) 已设置
- [ ] 构建版本号 (CFBundleVersion) 已设置
- [ ] 部署目标 (iOS Deployment Target) 设置正确
- [ ] 设备方向支持配置正确（竖屏/横屏）

### 2. 代码签名和证书
- [ ] 开发证书有效
- [ ] 分发证书有效
- [ ] App ID 在 Apple Developer Portal 已创建
- [ ] 配置文件 (Provisioning Profile) 有效且包含设备 UDID（Ad Hoc）/ 或 App Store 配置文件

### 3. App 图标和启动画面
- [ ] AppIcon 包含所有必需尺寸（App Store 要求 1024x1024 px）
- [ ] 图标不包含透明度 (alpha channel)
- [ ] 图标不包含圆角（系统会自动添加）
- [ ] 图标内容完整，不被切割
- [ ] 启动画面配置正确（UILaunchScreen 或 LaunchScreen.storyboard）

### 4. Info.plist 权限描述
- [ ] 所有使用的权限都有描述（例如：NSCameraUsageDescription, NSPhotoLibraryUsageDescription）
- [ ] 描述信息清晰，说明为什么需要这个权限
- [ ] 不包含模拟器检测代码（App Store 会拒绝）

### 5. 功能和性能
- [ ] App 无明显 bug
- [ ] 所有链接可访问（或正确处理离线状态）
- [ ] 没有崩溃
- [ ] 在多种设备和 iOS 版本上测试过
- [ ] 没有明显的性能问题

### 6. 隐私和法律
- [ ] 隐私政策 URL 可访问（https://）
- [ ] 隐私政策内容完整，包含：
  - 收集的数据类型
  - 数据使用目的
  - 数据保留政策
  - 用户权利（访问、删除数据）
  - 联系方式
- [ ] 如果包含第三方 SDK，确认其隐私政策
- [ ] 如果包含应用内购买，确认遵循 App Store 规则

### 7. App Store Connect 准备
- [ ] 准备好 App 名称（30 字符以内）
- [ ] 准备好副标题（30 字符以内）
- [ ] 准备好描述（4000 字符以内）
- [ ] 准备好推广文本（170 字符以内）
- [ ] 准备好关键词（100 字符以内）
- [ ] 准备好截图（不同设备尺寸）
- [ ] 准备好预览视频（可选，15-30 秒）
- [ ] 确定主要类别和次要类别
- [ ] 确定内容版权信息
- [ ] 确定年龄分级
- [ ] 确定广告标识符 (IDFA) 使用情况

## 🔍 深入检查

### Xcode 项目设置
- [ ] Build Settings > Code Signing 配置正确
- [ ] Build Settings > Enable Bitcode = NO（如果不需要）
- [ ] Build Settings > Strip Debug Symbols During Copy = YES (Release)
- [ ] Build Settings > Dead Code Stripping = YES
- [ ] 所有 Target Dependencies 配置正确

### 依赖管理
- [ ] 所有第三方库都有合法许可
- [ ] 不包含禁止使用的内容（例如：私有 API）
- [ ] 如果使用 CocoaPods/Carthage/SPM，确认依赖正确链接

### 测试
- [ ] 在真机上测试过（不仅是模拟器）
- [ ] 测试所有用户流程（注册、登录、主要功能）
- [ ] 测试网络连接失败的情况
- [ ] 测试低内存情况
- [ ] 测试后台恢复

### 本地化（如适用）
- [ ] 所有用户可见字符串都已本地化
- [ ] 截图和预览视频对应本地化版本

## ⚠️ 常见拒绝原因检查

- [ ] App 功能完整，不是 demo/beta 版本
- [ ] 不包含占位符内容
- [ ] UI 符合 Apple 设计规范
- [ ] 不包含指向其他应用商店的链接
- [ ] 如果包含用户生成内容，有适当的审核机制
- [ ] 如果包含应用内购买，功能正确
- [ ] 不包含恶意代码或病毒
- [ ] 不包含歧视性内容
- [ ] 遵守所有相关法律

## 📸 截图要求

### iPhone
- [ ] 6.7 英寸（iPhone 17 Pro Max）- 1290 x 2796 px
- [ ] 6.5 英寸（iPhone 17 Pro）- 1242 x 2688 px
- [ ] 5.5 英寸（iPhone 8 Plus）- 1242 x 2208 px（可选）

### iPad（如适用）
- [ ] 12.9 英寸 iPad Pro - 2048 x 2732 px
- [ ] 其他尺寸（可选）

### 要求
- [ ] 至少 3 张截图
- [ ] 最多 10 张截图
- [ ] 截图不包含透明区域
- [ ] 截图是 App 实际运行画面
- [ ] 不包含状态栏（可选）

## 🎥 预览视频要求（可选）

- [ ] 时长 15-30 秒
- [ ] 文件大小 < 500 MB
- [ ] 格式：.mov, .mp4, .m4v
- [ ] 不包含音频（可选）
- [ ] 展示核心功能

## ✅ 最终检查

- [ ] Archive 构建成功
- [ ] Archive 验证通过（Xcode > Product > Archive > Distribute App > Validate App）
- [ ] 所有信息填写完整
- [ ] 备份项目代码
- [ ] 记录版本号和构建号

## 📝 提交前最后确认

1. **App 二进制**：
   - 使用 Xcode Archive 功能构建
   - 选择正确的签名证书
   - 上传成功后状态变为 "Processing" → "Ready for Review"

2. **App Store Connect 信息**：
   - 所有必填字段已填写
   - 截图已上传
   - 隐私政策 URL 已填写
   - 年龄分级已设置

3. **提交审核**：
   - 点击 "Submit for Review"
   - 回答出口合规、内容版权、广告标识符等问题
   - 提交后状态变为 "Waiting for Review"

## 🚀 提交后

- [ ] 记录 App Store Connect 中的 App ID
- [ ] 监控审核状态
- [ ] 准备回复审核反馈（如被拒绝）
- [ ] 准备 App 上架后的宣传材料
